import React, { useEffect, useState } from "react";
import axios from "axios";
import Accordion from "react-bootstrap/Accordion";
import "../App.css";

function UserList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        const ListUsers = response.data;
        setUsers(ListUsers);
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
      });
  }, []);

  return (
    <div
      style={{ width: "60%", height: "auto", margin: "auto", marginTop: "2%" }}
    >
      {users.map((user) => (
        <Accordion defaultActiveKey="0">
          <Accordion.Item>
            <Accordion.Header>{user.name}</Accordion.Header>
            <Accordion.Body>
              <div className="user-detail">
                <strong>Username:</strong> {user.username}
              </div>
              <div className="user-detail">
                <strong>Email:</strong> {user.email}
              </div>
              <div className="user-detail-heading">Address:</div>
              <ul className="user-detail-list">
                <li>Street: {user.address.street}</li>
                <li>Suite: {user.address.suite}</li>
                <li>City: {user.address.city}</li>
                <li>Zipcode: {user.address.zipcode}</li>
              </ul>
              <div className="user-detail">
                <strong>Phone:</strong> {user.phone}
              </div>
              <div className="user-detail">
                <strong>Website:</strong>{" "}
                <a href={`http://${user.website}`}>{user.website}</a>
              </div>
              <div className="user-detail">
                <strong>Company:</strong>{" "}
              </div>
              <ul className="user-detail-list">
                <li>Name: {user.company.name}</li>
                <li>CatchPhrase: {user.company.catchPhrase}</li>
                <li>BS: {user.company.bs}</li>
              </ul>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>
      ))}
    </div>
  );
}

export default UserList;
