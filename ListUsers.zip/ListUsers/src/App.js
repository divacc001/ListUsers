import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import UserList from "./components/UserList";

function App() {
  return <UserList />;
}

export default App;
